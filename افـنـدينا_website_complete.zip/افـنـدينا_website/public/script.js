const form = document.getElementById("authForm");
const loginTab = document.getElementById("loginTab");
const registerTab = document.getElementById("registerTab");
const submitBtn = document.getElementById("submitBtn");
const message = document.getElementById("message");
const nameField = document.querySelector(".register-only");
const nameInput = document.getElementById("name");
const authCard = document.getElementById("authCard");
const dashboard = document.getElementById("dashboard");
const userName = document.getElementById("userName");
const userEmail = document.getElementById("userEmail");
const logoutBtn = document.getElementById("logoutBtn");

let mode = "login";

function setMessage(text, error=false) {
  message.textContent = text;
  message.style.color = error ? "#ff9d9d" : "#aaa";
}
function setMode(next) {
  mode = next;
  const register = mode === "register";
  nameField.classList.toggle("hidden", !register);
  nameInput.required = register;
  loginTab.classList.toggle("active", !register);
  registerTab.classList.toggle("active", register);
  submitBtn.textContent = register ? "إنشاء الحساب" : "دخول";
  setMessage("");
}
loginTab.onclick = () => setMode("login");
registerTab.onclick = () => setMode("register");

form.addEventListener("submit", async e => {
  e.preventDefault();
  setMessage("جارٍ التنفيذ...");
  submitBtn.disabled = true;

  const body = {
    name: nameInput.value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value
  };

  try {
    const response = await fetch(mode === "login" ? "/api/auth/login" : "/api/auth/register", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(body)
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.message || "حدث خطأ");

    localStorage.setItem("afendina_token", data.token);
    showDashboard(data.user);
  } catch (err) {
    setMessage(err.message, true);
  } finally {
    submitBtn.disabled = false;
  }
});

function showDashboard(user) {
  authCard.classList.add("hidden");
  dashboard.classList.remove("hidden");
  userName.textContent = user.name;
  userEmail.textContent = user.email;
}
logoutBtn.onclick = () => {
  localStorage.removeItem("afendina_token");
  dashboard.classList.add("hidden");
  authCard.classList.remove("hidden");
  form.reset();
  setMode("login");
};

async function restoreSession() {
  const token = localStorage.getItem("afendina_token");
  if (!token) return;
  try {
    const r = await fetch("/api/auth/me", {
      headers: {Authorization: `Bearer ${token}`}
    });
    const d = await r.json();
    if (!r.ok) throw new Error();
    showDashboard(d.user);
  } catch {
    localStorage.removeItem("afendina_token");
  }
}
restoreSession();
