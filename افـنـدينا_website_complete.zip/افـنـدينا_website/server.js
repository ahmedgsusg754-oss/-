const express = require("express");
const cors = require("cors");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const fs = require("fs");
const path = require("path");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "afendina-change-this-secret";

const DATA_DIR = path.join(__dirname, "data");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const PUBLIC_DIR = path.join(__dirname, "public");

function setup() {
  if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });
  if (!fs.existsSync(USERS_FILE)) fs.writeFileSync(USERS_FILE, "[]", "utf8");
}
function users() {
  setup();
  try { return JSON.parse(fs.readFileSync(USERS_FILE, "utf8")); }
  catch { return []; }
}
function saveUsers(data) {
  setup();
  fs.writeFileSync(USERS_FILE, JSON.stringify(data, null, 2), "utf8");
}
function publicUser(u) {
  return { id: u.id, name: u.name, email: u.email, createdAt: u.createdAt };
}
function tokenFor(u) {
  return jwt.sign({ id: u.id, email: u.email }, JWT_SECRET, { expiresIn: "7d" });
}
function auth(req, res, next) {
  const h = req.headers.authorization || "";
  if (!h.startsWith("Bearer ")) return res.status(401).json({success:false,message:"يجب تسجيل الدخول أولاً."});
  try {
    req.user = jwt.verify(h.slice(7), JWT_SECRET);
    next();
  } catch {
    res.status(401).json({success:false,message:"انتهت جلسة الدخول. سجل الدخول مرة أخرى."});
  }
}

app.disable("x-powered-by");
app.use(cors({ origin: true }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: true }));

app.get("/api/health", (req,res) => res.json({
  success:true, site:"افـنـدツ⁠يـنـا🥀🖤", status:"online"
}));

app.post("/api/auth/register", async (req,res) => {
  const name = String(req.body.name || "").trim();
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");

  if (name.length < 2) return res.status(400).json({success:false,message:"اكتب اسمك بشكل صحيح."});
  if (!email.includes("@")) return res.status(400).json({success:false,message:"اكتب بريداً إلكترونياً صحيحاً."});
  if (password.length < 6) return res.status(400).json({success:false,message:"كلمة المرور يجب أن تكون 6 أحرف على الأقل."});

  const list = users();
  if (list.some(u => u.email === email))
    return res.status(409).json({success:false,message:"هذا البريد مسجل بالفعل."});

  const u = {
    id: Date.now().toString(36) + Math.random().toString(36).slice(2,8),
    name, email,
    passwordHash: await bcrypt.hash(password, 12),
    createdAt: new Date().toISOString()
  };
  list.push(u);
  saveUsers(list);
  res.status(201).json({success:true,message:"تم إنشاء الحساب بنجاح.",token:tokenFor(u),user:publicUser(u)});
});

app.post("/api/auth/login", async (req,res) => {
  const email = String(req.body.email || "").trim().toLowerCase();
  const password = String(req.body.password || "");
  const u = users().find(x => x.email === email);

  if (!u || !(await bcrypt.compare(password, u.passwordHash)))
    return res.status(401).json({success:false,message:"البريد أو كلمة المرور غير صحيحة."});

  res.json({success:true,message:"تم تسجيل الدخول بنجاح.",token:tokenFor(u),user:publicUser(u)});
});

app.get("/api/auth/me", auth, (req,res) => {
  const u = users().find(x => x.id === req.user.id);
  if (!u) return res.status(404).json({success:false,message:"المستخدم غير موجود."});
  res.json({success:true,user:publicUser(u)});
});

app.post("/api/auth/logout", auth, (req,res) =>
  res.json({success:true,message:"تم تسجيل الخروج."})
);

app.get("/api/profile", auth, (req,res) => {
  const u = users().find(x => x.id === req.user.id);
  if (!u) return res.status(404).json({success:false,message:"المستخدم غير موجود."});
  res.json({success:true,profile:publicUser(u)});
});

app.use(express.static(PUBLIC_DIR));
app.get("*", (req,res,next) => {
  if (req.path.startsWith("/api/")) return next();
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});
app.use("/api", (req,res) => res.status(404).json({success:false,message:"المسار غير موجود."}));

setup();
app.listen(PORT, "0.0.0.0", () => {
  console.log(`\nافـنـدツ⁠يـنـا🥀🖤 يعمل على http://localhost:${PORT}\n`);
});
