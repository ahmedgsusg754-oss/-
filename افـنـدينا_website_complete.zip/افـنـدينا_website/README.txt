# افـنـدツ⁠يـنـا🥀🖤

## تشغيل الموقع

### 1) ثبّت Node.js
ثبّت Node.js على الكمبيوتر.

### 2) افتح هذا المجلد في Terminal / CMD

### 3) نفّذ:
npm install

### 4) شغّل:
npm start

### 5) افتح:
http://localhost:3000

## الملفات
- server.js: السيرفر وواجهة API.
- public/index.html: صفحة الدخول.
- public/style.css: التصميم.
- public/script.js: التسجيل والدخول.
- data/users.json: حسابات المستخدمين.
- .env: إعدادات التشغيل.
- package.json: الحزم والأوامر.

لا تفتح index.html مباشرة؛ شغّل server.js ثم افتح localhost:3000.
