import express from "express";
import http from "http";
import { Server } from "socket.io";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database(path.join(__dirname, "afnndyna.db"));

db.exec(`CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
 bio TEXT DEFAULT '', avatar TEXT DEFAULT '', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS messages (
 id INTEGER PRIMARY KEY AUTOINCREMENT, room TEXT NOT NULL,
 username TEXT NOT NULL, text TEXT NOT NULL, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);`);

app.use(express.json({limit:"1mb"}));
app.use(express.static(path.join(__dirname,"public")));

app.post("/api/users",(req,res)=>{
 const username=String(req.body.username||"").trim().slice(0,24);
 if(!username) return res.status(400).json({error:"اكتب اسمك"});
 db.prepare("INSERT OR IGNORE INTO users(username) VALUES(?)").run(username);
 res.json(db.prepare("SELECT * FROM users WHERE username=?").get(username));
});
app.get("/api/messages/:room",(req,res)=>{
 res.json(db.prepare("SELECT username,text,created_at FROM messages WHERE room=? ORDER BY id DESC LIMIT 80")
 .all(req.params.room).reverse());
});

io.on("connection",socket=>{
 socket.on("joinRoom",({room,username})=>{
  socket.join(room); socket.data.room=room; socket.data.username=username;
  socket.to(room).emit("system",{text:`${username} دخل الغرفة`});
 });
 socket.on("message",({room,text})=>{
  const username=socket.data.username, clean=String(text||"").trim().slice(0,500);
  if(!username||!clean)return;
  db.prepare("INSERT INTO messages(room,username,text) VALUES(?,?,?)").run(room,username,clean);
  io.to(room).emit("message",{username,text:clean,created_at:new Date().toISOString()});
 });
 socket.on("typing",({room})=>socket.to(room).emit("typing",{username:socket.data.username}));
});
server.listen(process.env.PORT||3000,()=>console.log("افـنـدツـيـنـا running"));
