const socket=io();let username=localStorage.getItem("afnndyna_username")||"",room="egypt";
const $=id=>document.getElementById(id),rooms={egypt:"🇪🇬 مصر",arab:"🌍 العرب",friends:"💗 تعارف وأصدقاء"};
function show(){if(!username)return;$("login").classList.add("hidden");$("app").classList.remove("hidden");$("profileName").textContent=username}
if(username)show();
$("enter").onclick=async()=>{let name=$("username").value.trim();if(!name)return alert("اكتب اسمك أولاً");let r=await fetch("/api/users",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({username:name})}),d=await r.json();if(!r.ok)return alert(d.error);username=d.username;localStorage.setItem("afnndyna_username",username);show();join("egypt")};
async function join(r){room=r;$("roomTitle").textContent=rooms[r];document.querySelectorAll(".room").forEach(x=>x.classList.toggle("active",x.dataset.room===r));$("messages").innerHTML="";(await fetch("/api/messages/"+r).then(x=>x.json())).forEach(add);socket.emit("joinRoom",{room:r,username})}
document.querySelectorAll(".room").forEach(x=>x.onclick=()=>join(x.dataset.room));
$("composer").onsubmit=e=>{e.preventDefault();let t=$("text").value.trim();if(t){socket.emit("message",{room,text:t});$("text").value=""}};
$("text").oninput=()=>socket.emit("typing",{room});
socket.on("message",add);socket.on("system",x=>{let e=document.createElement("div");e.className="sys";e.textContent=x.text;$("messages").append(e);scroll()});
socket.on("typing",x=>{$("typing").textContent=x.username?x.username+" يكتب الآن...":"";clearTimeout(window.tt);window.tt=setTimeout(()=>$("typing").textContent="",1200)});
function add(m){let e=document.createElement("div");e.className="msg "+(m.username===username?"mine":"");let b=document.createElement("b");b.textContent=m.username;let p=document.createElement("p");p.textContent=m.text;e.append(b,p);$("messages").append(e);scroll()}
function scroll(){$("messages").scrollTop=$("messages").scrollHeight}
function profile(){$("profile").classList.remove("hidden")}$("profileBtn").onclick=profile;$("navProfile").onclick=profile;$("closeProfile").onclick=()=>$("profile").classList.add("hidden");$("logout").onclick=()=>{localStorage.removeItem("afnndyna_username");location.reload()};if(username)join(room);
