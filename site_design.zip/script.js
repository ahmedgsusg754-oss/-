document.querySelector('.menu')?.addEventListener('click', () => {
  const nav = document.querySelector('nav');
  nav.style.display = nav.style.display === 'flex' ? 'none' : 'flex';
  nav.style.flexDirection = 'column';
  nav.style.position = 'absolute';
  nav.style.top = '72px';
  nav.style.right = '4%';
  nav.style.background = '#0b1020';
  nav.style.padding = '18px';
  nav.style.borderRadius = '14px';
});
