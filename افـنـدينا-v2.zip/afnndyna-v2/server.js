import express from "express";
import http from "http";
import {Server} from "socket.io";
import Database from "better-sqlite3";
import path from "path";
import {fileURLToPath} from "url";
const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(), server=http.createServer(app), io=new Server(server);
const db=new Database(path.join(__dirname,"afnndyna.db"));
db.exec(`CREATE TABLE IF NOT EXISTS users(
id INTEGER PRIMARY KEY AUTOINCREMENT,username TEXT UNIQUE NOT NULL,bio TEXT DEFAULT '',
gender TEXT DEFAULT '',age INTEGER DEFAULT 18,avatar TEXT DEFAULT '',online INTEGER DEFAULT 0,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages(
id INTEGER PRIMARY KEY AUTOINCREMENT,room TEXT NOT NULL,username TEXT NOT NULL,text TEXT NOT NULL,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS private_messages(
id INTEGER PRIMARY KEY AUTOINCREMENT,sender TEXT NOT NULL,receiver TEXT NOT NULL,text TEXT NOT NULL,
created_at DATETIME DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS reports(
id INTEGER PRIMARY KEY AUTOINCREMENT,reporter TEXT,target TEXT,reason TEXT,created_at DATETIME DEFAULT CURRENT_TIMESTAMP);`);
app.use(express.json({limit:"1mb"}));app.use(express.static(path.join(__dirname,"public")));

app.post("/api/users",(req,res)=>{
 const username=String(req.body.username||"").trim().slice(0,24);
 if(!username)return res.status(400).json({error:"اكتب اسمك"});
 db.prepare("INSERT OR IGNORE INTO users(username) VALUES(?)").run(username);
 db.prepare("UPDATE users SET online=1 WHERE username=?").run(username);
 res.json(db.prepare("SELECT id,username,bio,gender,age,avatar,online FROM users WHERE username=?").get(username));
});
app.patch("/api/users/:username",(req,res)=>{
 const u=req.params.username,b=String(req.body.bio||"").slice(0,160),g=String(req.body.gender||"").slice(0,20);
 const age=Math.max(13,Math.min(99,Number(req.body.age)||18));
 db.prepare("UPDATE users SET bio=?,gender=?,age=? WHERE username=?").run(b,g,age,u);
 res.json(db.prepare("SELECT * FROM users WHERE username=?").get(u));
});
app.get("/api/users",(req,res)=>res.json(db.prepare("SELECT username,bio,gender,age,avatar,online FROM users ORDER BY online DESC,created_at DESC LIMIT 100").all()));
app.get("/api/messages/:room",(req,res)=>res.json(db.prepare("SELECT username,text,created_at FROM messages WHERE room=? ORDER BY id DESC LIMIT 100").all(req.params.room).reverse()));
app.get("/api/private/:a/:b",(req,res)=>res.json(db.prepare("SELECT sender,receiver,text,created_at FROM private_messages WHERE (sender=? AND receiver=?) OR (sender=? AND receiver=?) ORDER BY id ASC LIMIT 100").all(req.params.a,req.params.b,req.params.b,req.params.a)));
app.post("/api/reports",(req,res)=>{
 const {reporter,target,reason}=req.body||{}; if(!reporter||!target)return res.status(400).json({error:"بيانات ناقصة"});
 db.prepare("INSERT INTO reports(reporter,target,reason) VALUES(?,?,?)").run(reporter,target,String(reason||"بدون سبب").slice(0,200));
 res.json({ok:true});
});

io.on("connection",s=>{
 s.on("joinRoom",({room,username})=>{s.join(room);s.data.username=username;s.data.room=room;db.prepare("UPDATE users SET online=1 WHERE username=?").run(username);s.to(room).emit("system",{text:`${username} دخل الغرفة`});});
 s.on("leave",()=>{if(s.data.username)db.prepare("UPDATE users SET online=0 WHERE username=?").run(s.data.username);});
 s.on("message",({room,text})=>{const u=s.data.username,t=String(text||"").trim().slice(0,500);if(!u||!t)return;db.prepare("INSERT INTO messages(room,username,text) VALUES(?,?,?)").run(room,u,t);io.to(room).emit("message",{username:u,text:t,created_at:new Date().toISOString()});});
 s.on("privateMessage",({to,text})=>{const from=s.data.username,t=String(text||"").trim().slice(0,500);if(!from||!to||!t)return;db.prepare("INSERT INTO private_messages(sender,receiver,text) VALUES(?,?,?)").run(from,to,t);for(const [id,sk] of io.sockets.sockets)if(sk.data.username===to||sk.data.username===from)sk.emit("privateMessage",{sender:from,receiver:to,text:t,created_at:new Date().toISOString()});});
 s.on("typing",({room})=>s.to(room).emit("typing",{username:s.data.username}));
 s.on("disconnect",()=>{if(s.data.username)db.prepare("UPDATE users SET online=0 WHERE username=?").run(s.data.username);});
});
server.listen(process.env.PORT||3000,()=>console.log("افـنـدツـيـنـا v2 running"));
